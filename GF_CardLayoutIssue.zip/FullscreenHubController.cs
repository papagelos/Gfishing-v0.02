using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;   // New Input System
#endif

namespace GalacticFishing.UI
{
    [RequireComponent(typeof(CanvasGroup))]
    [AddComponentMenu("Galactic Fishing/UI/Fullscreen Hub Controller")]
    public sealed class FullscreenHubController : MonoBehaviour
    {
        [Header("Toggle (New Input System)")]
        public bool useRightMouse = true;
        public bool requireHold = false;
        [Range(0f, 1f)] public float holdSeconds = 0.2f;

        [Header("Behavior")]
        public bool pauseTime = true;
        public GameObject[] hideWhenOpen;

        [Header("Animation")]
        [Range(0f, 1f)] public float fadeSeconds = 0.18f;

        [Header("Options")]
        public bool openOnStart = false;
        public bool deactivateOnClose = false;
        public bool logInput = false;

        [Header("Cursor")]
        public bool showCursorWhenOpen   = true;
        public bool showCursorWhenClosed = true;   // <-- keep cursor visible in gameplay
        public bool lockCursorWhenOpen   = false;
        public bool lockCursorWhenClosed = false;

        CanvasGroup _group;
        bool _open, _animating;
        float _holdT;

        void Awake()
        {
            _group = GetComponent<CanvasGroup>();
            SetOpen(openOnStart, true);
        }

        void Update()
        {
            bool togglePressed = false;
            bool toggleHeld    = false;

#if ENABLE_INPUT_SYSTEM
            if (useRightMouse && Mouse.current != null)
            {
                togglePressed = Mouse.current.rightButton.wasPressedThisFrame;
                toggleHeld    = Mouse.current.rightButton.isPressed;
            }
            if (_open && Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame)
                Toggle();
#else
            // Compiles only if legacy Input is enabled in project
            togglePressed = Input.GetMouseButtonDown(1);
            toggleHeld    = Input.GetMouseButton(1);
            if (_open && Input.GetKeyDown(KeyCode.Escape)) Toggle();
#endif

            if (requireHold)
            {
                if (!_open && toggleHeld)
                {
                    _holdT += Time.unscaledDeltaTime;
                    if (_holdT >= holdSeconds) Toggle();
                }
                if (!toggleHeld) _holdT = 0f;
            }
            else
            {
                if (togglePressed)
                {
                    if (logInput) Debug.Log("[Hub] Toggle via RMB");
                    Toggle();
                }
            }
        }

        public void Toggle()
        {
            if (_animating) return;
            SetOpen(!_open, false);
        }

        void SetOpen(bool open, bool instant)
        {
            _open = open;

            if (hideWhenOpen != null)
            {
                foreach (var go in hideWhenOpen)
                    if (go) go.SetActive(!open);
            }

            StopAllCoroutines();
            if (instant) ApplyImmediate(open);
            else StartCoroutine(Fade(open));
        }

        void ApplyImmediate(bool open)
        {
            if (!_group) _group = GetComponent<CanvasGroup>();

            _group.alpha = open ? 1f : 0f;
            _group.blocksRaycasts = open;
            _group.interactable   = open;

            ApplyCursor(open);
            if (pauseTime) Time.timeScale = open ? 0f : 1f;

            if (!open && deactivateOnClose)
                gameObject.SetActive(false);
        }

        IEnumerator Fade(bool open)
        {
            _animating = true;
            if (!_group) _group = GetComponent<CanvasGroup>();
            if (open && !gameObject.activeSelf)
                gameObject.SetActive(true);

            float start  = _group.alpha;
            float target = open ? 1f : 0f;
            float t = 0f;

            while (t < fadeSeconds)
            {
                t += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(t / Mathf.Max(0.0001f, fadeSeconds));
                _group.alpha = Mathf.Lerp(start, target, k);
                yield return null;
            }

            _group.alpha = target;
            _group.blocksRaycasts = open;
            _group.interactable   = open;

            ApplyCursor(open);
            if (pauseTime) Time.timeScale = open ? 0f : 1f;

            if (!open && deactivateOnClose)
                gameObject.SetActive(false);

            _animating = false;
        }

        void ApplyCursor(bool open)
        {
            bool show = open ? showCursorWhenOpen   : showCursorWhenClosed;
            bool lockIt = open ? lockCursorWhenOpen : lockCursorWhenClosed;

            Cursor.visible = show;
            Cursor.lockState = lockIt ? CursorLockMode.Locked : CursorLockMode.None;
        }

        // ------- Editor helpers -------
        [ContextMenu("Editor: Force Open (Immediate)")]
        void EditorForceOpen()  => SetOpen(true,  true);

        [ContextMenu("Editor: Force Closed (Immediate)")]
        void EditorForceClosed() => SetOpen(false, true);
    }
}
