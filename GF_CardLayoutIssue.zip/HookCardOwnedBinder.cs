// Assets/Scripts/UI/HookCardOwnedBinder.cs
// v3: Namespace-proof (no direct compile dependency on FishRegistry).
// - The "Registry" field now accepts ANY ScriptableObject/asset; we reflect a public or private field named "fishes".
// - Each entry is assumed to be a UnityEngine.Object with .name and (optionally) a string field/property "displayName".
// - You still get live updates via InventoryService.OnChanged and SetSpeciesId(int) for direct injection.
//
// Wiring: assign Species Name, Sub Text, and drag your FishRegistry asset into "Registry".

using UnityEngine;
using TMPro;
using System.Collections;
using System.Reflection;

[DefaultExecutionOrder(200)]
public class HookCardOwnedBinder : MonoBehaviour
{
    [Header("HookCard UI (assign in prefab)")]
    [SerializeField] private TMP_Text speciesName;
    [SerializeField] private TMP_Text subText;

    [Header("Data (same source as grid)")]
    [Tooltip("Drag your FishRegistry asset here. The script will read its 'fishes' list via reflection.")]
    [SerializeField] private UnityEngine.Object registry;

    [Header("Options")]
    [SerializeField] private bool logs = false;

    string _lastTitle = null;
    int _currentId = -1;

    // Cache for reflection
    FieldInfo _fishesField;
    PropertyInfo _fishesProp;

    // --- Public API: allow external systems to set the id directly (best case).
    public void SetSpeciesId(int speciesId)
    {
        _currentId = speciesId;
        if (logs) Debug.Log($"[HookCardOwnedBinder] External SetSpeciesId → {speciesId}");
        UpdateText();
    }

    void Awake()
    {
        if (registry != null)
        {
            var t = registry.GetType();
            _fishesField = t.GetField("fishes", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            _fishesProp  = t.GetProperty("fishes", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (logs) Debug.Log($"[HookCardOwnedBinder] Registry bound via reflection. field? {(_fishesField!=null)} prop? {(_fishesProp!=null)}");
        }
    }

    void OnEnable()
    {
        InventoryService.OnChanged += OnInventoryChanged;
        ForceRefresh();
    }

    void OnDisable()
    {
        InventoryService.OnChanged -= OnInventoryChanged;
        _currentId = -1;
        _lastTitle = null;
    }

    void Update()
    {
        if (!speciesName) return;

        var title = speciesName.text?.Trim();
        if (title != _lastTitle)
        {
            _lastTitle = title;
            _currentId = ResolveIdFromTitle(title);
            if (logs) Debug.Log($"[HookCardOwnedBinder] Title change → '{title}'  id={_currentId}");
            UpdateText();
        }
    }

    void OnInventoryChanged()
    {
        if (isActiveAndEnabled)
            UpdateText();
    }

    void ForceRefresh()
    {
        if (speciesName)
        {
            _lastTitle = speciesName.text?.Trim();
            _currentId = ResolveIdFromTitle(_lastTitle);
        }
        UpdateText();
    }

    int ResolveIdFromTitle(string title)
    {
        if (registry == null || string.IsNullOrWhiteSpace(title))
            return _currentId >= 0 ? _currentId : -1;

        string want = Normalize(title);
        string wantNoDigits = StripTrailingDigits(want);

        IList fishes = GetFishesList();
        if (fishes == null) return -1;

        int best = -1;

        for (int i = 0; i < fishes.Count; i++)
        {
            var defObj = fishes[i] as UnityEngine.Object;
            if (!defObj) continue;

            string assetName = Normalize(defObj.name);
            string displayName = Normalize(GetDisplayName(defObj));

            // Exact match first
            if (want == displayName || want == assetName) return i;

            // Variant-safe trailing digits
            if (wantNoDigits == displayName || wantNoDigits == assetName) best = i;
            else if (want.StartsWith(displayName) || want.StartsWith(assetName) ||
                     displayName.StartsWith(wantNoDigits) || assetName.StartsWith(wantNoDigits))
                best = i;
        }

        return best;
    }

    IList GetFishesList()
    {
        if (registry == null) return null;
        if (_fishesField != null) return _fishesField.GetValue(registry) as IList;
        if (_fishesProp  != null) return _fishesProp.GetValue(registry) as IList;
        return null;
    }

    string GetDisplayName(UnityEngine.Object fishDef)
    {
        // Try field or property named "displayName"
        var t = fishDef.GetType();
        var f = t.GetField("displayName", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        if (f != null && f.FieldType == typeof(string))
            return (string)f.GetValue(fishDef);

        var p = t.GetProperty("displayName", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        if (p != null && p.PropertyType == typeof(string))
            return (string)p.GetValue(fishDef, null);

        return fishDef.name; // fallback
    }

    void UpdateText()
    {
        int n = 0;

        if (_currentId >= 0 && InventoryService.IsInitialized)
        {
            foreach (var t in InventoryService.All())
            {
                if (t.id == _currentId) { n = Mathf.Max(0, t.count); break; }
            }
        }

        if (subText) subText.text = $"OWNED: {n}";
        if (logs) Debug.Log($"[HookCardOwnedBinder] Shown → OWNED: {n} (id={_currentId})");
    }

    static string Normalize(string s)
    {
        if (string.IsNullOrEmpty(s)) return "";
        System.Text.StringBuilder sb = new System.Text.StringBuilder(s.Length);
        foreach (char c in s)
        {
            if (char.IsLetterOrDigit(c)) sb.Append(char.ToLowerInvariant(c));
        }
        return sb.ToString();
    }

    static string StripTrailingDigits(string s)
    {
        if (string.IsNullOrEmpty(s)) return "";
        int end = s.Length;
        while (end > 0 && char.IsDigit(s[end - 1])) end--;
        return s.Substring(0, end);
    }
}
