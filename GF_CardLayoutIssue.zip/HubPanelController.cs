using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using TMPro;

namespace GalacticFishing.UI
{
    public sealed class HubPanelController : MonoBehaviour
    {
        [Header("Scene References")]
        [SerializeField] private Transform leftColumn;   // Panel_Hub/LeftColumn
        [SerializeField] private Transform rightGrid;    // Panel_Hub/RightGrid

        [Header("Worlds Tab")]
        [SerializeField] private GalacticFishing.WorldManager worldManager;
        [SerializeField] private List<GalacticFishing.WorldDefinition> worlds = new();

        [Header("Custom Tabs")]
        [SerializeField] private List<CustomPage> customPages = new(); // e.g., UPGRADES

        [Header("Behaviour")]
        [SerializeField] private bool closePanelAfterWorldPick = false;

        [Header("GRID Label Style (Right side)")]
        [SerializeField] private bool gridUseAutoSize = true;
        [SerializeField] private float gridAutoMin = 16f;
        [SerializeField] private float gridAutoMax = 40f;
        [SerializeField] private TextOverflowModes gridOverflow = TextOverflowModes.Ellipsis;
        [SerializeField] private bool gridWordWrap = false;
        [SerializeField] private bool smartTwoLineIfLong = false;
        [SerializeField] private int twoLineThreshold = 12;

        [Header("LEFT TAB Label Style (override)")]
        [SerializeField] private bool leftUseAutoSize = true;
        [SerializeField] private float leftAutoMin = 28f;
        [SerializeField] private float leftAutoMax = 96f;
        [SerializeField] private TextOverflowModes leftOverflow = TextOverflowModes.Ellipsis;
        [SerializeField] private bool leftWordWrap = false;

        [Header("Pagination (auto builds PREV/NEXT)")]
        [SerializeField] private bool autoBuildPagerUI = true;
        [SerializeField] private bool showPagerWhenSinglePage = false;
        [SerializeField] private Vector2 pagerOffset = new Vector2(0f, -16f);
        [SerializeField] private bool pagerStackVertical = false; // show stack (1, —, 2) instead of 1/2
        [SerializeField] private string pagerDivider = "—";
        [SerializeField] private string pagerSlash = "/";

        // runtime pager refs
        [SerializeField] private Button pagerPrev;
        [SerializeField] private TMP_Text pagerText;
        [SerializeField] private Button pagerNext;
        private LayoutElement pagerLabelLE; // <— was missing

        [Header("Pagination Style")]
        [SerializeField] private string prevLabel = "PREV <";
        [SerializeField] private string nextLabel = "> NEXT";
        [SerializeField] private float pagerFontSize = 32f;
        [SerializeField] private Color pagerTextColor = Color.white;
        [SerializeField] private Vector2 pagerButtonSize = new Vector2(140f, 44f);
        [SerializeField] private float pagerSpacing = 24f;

        [Tooltip("Optional sprite for PREV/NEXT button background (leave null for clean).")]
        [SerializeField] private Sprite pagerButtonSprite = null;

        [Tooltip("Background color; if fully transparent, we'll auto-set to very small alpha so the full rect is clickable.")]
        [SerializeField] private Color pagerButtonColor = new Color(1, 1, 1, 0f);

        // ----- internal -----
        private List<Cell> _left = new();
        private List<Cell> _grid = new();

        private int _currentTabType = 0;  // 0=Museum, 1=Worlds, 2+=Custom
        private int _currentPage = 0;
        private int _pageSize = 15;
        private int _pageCount = 1;

        [System.Serializable] public class CustomPage { public string tabLabel = "UPGRADES"; public List<CustomItem> items = new(); }
        [System.Serializable] public class CustomItem { public string label = "Item"; public Sprite icon; public UnityEvent onClick; }

        private struct Cell
        {
            public GameObject go;
            public Button     button;
            public TMP_Text   label;
            public Image      icon;
        }

        void Awake()
        {
            if (!leftColumn || !rightGrid) { Debug.LogWarning("[HubPanelController] Assign LeftColumn & RightGrid."); return; }

            _left = CollectCells(leftColumn);
            _grid = CollectCells(rightGrid);
            _pageSize = _grid.Count;

            ApplyLeftLabelStyle();
            ApplyGridLabelStyle();

            if (autoBuildPagerUI) EnsurePagerUI();
            WirePagerButtons();

            SetupLeftTabs();
            ShowMuseumPage();
        }

        // ---------- collect tiles ----------
        private List<Cell> CollectCells(Transform parent)
        {
            var list = new List<Cell>(parent.childCount);
            for (int i = 0; i < parent.childCount; i++)
            {
                var t = parent.GetChild(i);
                var go = t.gameObject;

                var img = go.GetComponent<Image>(); if (!img) img = go.AddComponent<Image>();
                var btn = go.GetComponent<Button>(); if (!btn) btn = go.AddComponent<Button>();
                if (!btn.targetGraphic) btn.targetGraphic = img;
                btn.navigation = new Navigation { mode = Navigation.Mode.None };

                var label = go.GetComponentInChildren<TMP_Text>(true);
                Image icon = null; var iconTr = go.transform.Find("Icon"); if (iconTr) icon = iconTr.GetComponent<Image>();

                list.Add(new Cell { go = go, button = btn, label = label, icon = icon });
            }
            return list;
        }

        private void StyleLabel(TMP_Text L, bool useAuto, float min, float max, TextOverflowModes overflow, bool wrap)
        {
            if (!L) return;
            L.enableAutoSizing = useAuto;
            if (useAuto) { L.fontSizeMin = min; L.fontSizeMax = max; }
            L.overflowMode = overflow;
            L.enableWordWrapping = wrap;
            L.ForceMeshUpdate();
        }

        private void ApplyLeftLabelStyle() { foreach (var c in _left) StyleLabel(c.label, leftUseAutoSize, leftAutoMin, leftAutoMax, leftOverflow, leftWordWrap); }
        private void ApplyGridLabelStyle() { foreach (var c in _grid) StyleLabel(c.label, gridUseAutoSize, gridAutoMin, gridAutoMax, gridOverflow, gridWordWrap); }

        private string MakeFit(string s)
        {
            if (!smartTwoLineIfLong || string.IsNullOrEmpty(s) || s.Length < twoLineThreshold) return s;
            int space = s.IndexOf(' ');
            return (space > 0 && space < s.Length - 1) ? s[..space] + "\n" + s[(space + 1)..] : s;
        }

        // ---------- pager UI ----------
        private void EnsurePagerUI()
        {
            if (pagerPrev && pagerText && pagerNext) return;

            var rg = rightGrid as RectTransform;
            if (!rg) return;

            // Root container
            var rootGO = new GameObject("Pager", typeof(RectTransform));
            var rootRT = (RectTransform)rootGO.transform;
            rootRT.SetParent(rg, false);
            rootRT.anchorMin = new Vector2(0.5f, 0f);
            rootRT.anchorMax = new Vector2(0.5f, 0f);
            rootRT.pivot     = new Vector2(0.5f, 1f);
            rootRT.anchoredPosition = pagerOffset;
            rootRT.SetAsLastSibling(); // on top for raycasts

            // Layout
            var h = rootGO.AddComponent<HorizontalLayoutGroup>();
            h.childAlignment = TextAnchor.MiddleCenter;
            h.spacing = pagerSpacing;
            h.padding = new RectOffset(0,0,0,0);

            // PREV button
            pagerPrev = CreateTextButton("Prev", prevLabel, rootRT);

            // label
            pagerText = CreatePagerLabel("Page", "1/1", rootRT);

            // NEXT button
            pagerNext = CreateTextButton("Next", nextLabel, rootRT);
        }

        private Button CreateTextButton(string name, string label, RectTransform parent)
        {
            // Root button includes LayoutElement so HorizontalLayoutGroup respects its slot.
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button), typeof(LayoutElement));
            var rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            rt.sizeDelta = pagerButtonSize;

            var layout = go.GetComponent<LayoutElement>();
            layout.minWidth = pagerButtonSize.x; layout.preferredWidth = pagerButtonSize.x;
            layout.minHeight = pagerButtonSize.y; layout.preferredHeight = pagerButtonSize.y;

            var img = go.GetComponent<Image>();
            img.sprite = pagerButtonSprite;
            img.color = pagerButtonColor;
            img.raycastTarget = true;
            img.alphaHitTestMinimumThreshold = 0f;

            var btn = go.GetComponent<Button>();
            btn.targetGraphic = img;
            btn.transition = Selectable.Transition.None;

            var txtGo = new GameObject("Text", typeof(RectTransform));
            var txtRt = (RectTransform)txtGo.transform;
            txtRt.SetParent(rt, false);
            txtRt.anchorMin = Vector2.zero;
            txtRt.anchorMax = Vector2.one;
            txtRt.offsetMin = Vector2.zero;
            txtRt.offsetMax = Vector2.zero;
            txtRt.pivot = new Vector2(0.5f, 0.5f);

            var tmp = txtGo.AddComponent<TextMeshProUGUI>();
            tmp.text = label;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.enableAutoSizing = false;
            tmp.fontSize = pagerFontSize;
            tmp.color = pagerTextColor;
            tmp.enableWordWrapping = false;
            tmp.overflowMode = TextOverflowModes.Overflow;
            tmp.raycastTarget = false;

            return btn;
        }

        private TMP_Text CreatePagerLabel(string name, string label, RectTransform parent)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(LayoutElement));
            var rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            rt.sizeDelta = new Vector2(120f, pagerButtonSize.y);

            pagerLabelLE = go.GetComponent<LayoutElement>();
            pagerLabelLE.minWidth = 120f; pagerLabelLE.preferredWidth = 120f;
            pagerLabelLE.minHeight = pagerButtonSize.y; pagerLabelLE.preferredHeight = pagerButtonSize.y;

            var tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.enableWordWrapping = false; tmp.overflowMode = TextOverflowModes.Overflow;
            tmp.text = label;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.enableAutoSizing = false;
            tmp.fontSize = Mathf.Max(18f, pagerFontSize * 0.8f);
            tmp.color = pagerTextColor;
            tmp.raycastTarget = false;
            return tmp;
        }

        private void WirePagerButtons()
        {
            if (pagerPrev) { pagerPrev.onClick.RemoveAllListeners(); pagerPrev.onClick.AddListener(PrevPage); }
            if (pagerNext) { pagerNext.onClick.RemoveAllListeners(); pagerNext.onClick.AddListener(NextPage); }
        }

        private void PrevPage()
        {
            if (_pageCount <= 1) return;
            _currentPage = Mathf.Clamp(_currentPage - 1, 0, _pageCount - 1);
            RedrawCurrentTab();
        }

        private void NextPage()
        {
            if (_pageCount <= 1) return;
            _currentPage = Mathf.Clamp(_currentPage + 1, 0, _pageCount - 1);
            RedrawCurrentTab();
        }

        private void UpdatePager(int page, int pages)
        {
            _pageCount = Mathf.Max(1, pages);
            _currentPage = Mathf.Clamp(page, 0, _pageCount - 1);

            ApplyPagerMode(_currentPage + 1, _pageCount);
            if (pagerPrev) pagerPrev.interactable = (_currentPage > 0);
            if (pagerNext) pagerNext.interactable = (_currentPage < _pageCount - 1);

            var show = showPagerWhenSinglePage ? true : (_pageCount > 1);
            if (pagerPrev) pagerPrev.gameObject.SetActive(show);
            if (pagerText) pagerText.gameObject.SetActive(show);
            if (pagerNext) pagerNext.gameObject.SetActive(show);
        }

        // ---------- tabs ----------
        private void SetupLeftTabs()
        {
            if (_left.Count > 0 && _left[0].label) _left[0].label.text = "MUSEUM";
            if (_left.Count > 1 && _left[1].label) _left[1].label.text = "WORLDS";

            if (_left.Count > 0) _left[0].button.onClick.AddListener(() => { _currentTabType = 0; _currentPage = 0; ShowMuseumPage(); });
            if (_left.Count > 1) _left[1].button.onClick.AddListener(() => { _currentTabType = 1; _currentPage = 0; ShowWorldsPage(); });

            int start = 2;
            for (int i = 0; i < customPages.Count; i++)
            {
                int li = start + i; if (li >= _left.Count) break;
                var page = customPages[i];
                if (_left[li].label) _left[li].label.text = page.tabLabel;
                int cap = i;
                _left[li].button.onClick.AddListener(() =>
                {
                    _currentTabType = 2 + cap;
                    _currentPage = 0;
                    ShowCustomPage(cap);
                });
            }
        }

        private void RedrawCurrentTab()
        {
            if (_currentTabType == 0) ShowMuseumPage();
            else if (_currentTabType == 1) ShowWorldsPage();
            else ShowCustomPage(_currentTabType - 2);
        }

        // ---------- pages ----------
        private void ShowMuseumPage()
        {
            for (int i = 0; i < _grid.Count; i++)
            {
                var c = _grid[i];
                c.go.SetActive(true);
                if (c.icon) c.icon.enabled = false;

                string text = (i < 10) ? "SELL" : "Future Content";
                if (smartTwoLineIfLong) text = MakeFit(text);
                if (c.label) c.label.text = text;

                c.button.onClick.RemoveAllListeners();
            }
            UpdatePager(0, 1);
        }

        private void ShowWorldsPage()
        {
            int total = worlds.Count;
            int pages = Mathf.Max(1, Mathf.CeilToInt(total / (float)_pageSize));
            _currentPage = Mathf.Clamp(_currentPage, 0, pages - 1);

            int start = _currentPage * _pageSize;
            int end   = Mathf.Min(start + _pageSize, total);

            int gridIdx = 0;
            for (int i = start; i < end && gridIdx < _grid.Count; i++, gridIdx++)
            {
                var c = _grid[gridIdx];
                var w = worlds[i];
                c.go.SetActive(true);
                if (c.icon) { c.icon.sprite = null; c.icon.enabled = false; }

                string name = (w && !string.IsNullOrWhiteSpace(w.displayName)) ? w.displayName : $"World {i + 1}";
                if (smartTwoLineIfLong) name = MakeFit(name);
                if (c.label) c.label.text = name;

                c.button.onClick.RemoveAllListeners();
                int captureIndex = i;
                c.button.onClick.AddListener(() =>
                {
                    if (worldManager && worlds[captureIndex] != null)
                    {
                        worldManager.world = worlds[captureIndex];
                        worldManager.lakeIndex = 0;
                        worldManager.ApplyWorldContext();
                    }
                    if (closePanelAfterWorldPick)
                    {
                        var cg = GetComponent<CanvasGroup>(); if (cg) cg.alpha = 0f;
                        gameObject.SetActive(false);
                    }
                });
            }

            for (; gridIdx < _grid.Count; gridIdx++) _grid[gridIdx].go.SetActive(false);

            UpdatePager(_currentPage, pages);
        }

        private void ShowCustomPage(int pageIndex)
        {
            if (pageIndex < 0 || pageIndex >= customPages.Count) { UpdatePager(0, 1); return; }
            var page = customPages[pageIndex];

            int total = page.items.Count;
            int pages = Mathf.Max(1, Mathf.CeilToInt(total / (float)_pageSize));
            _currentPage = Mathf.Clamp(_currentPage, 0, pages - 1);

            int start = _currentPage * _pageSize;
            int end   = Mathf.Min(start + _pageSize, total);

            int gridIdx = 0;
            for (int i = start; i < end && gridIdx < _grid.Count; i++, gridIdx++)
            {
                var c = _grid[gridIdx];
                var item = page.items[i];
                c.go.SetActive(true);

                string text = smartTwoLineIfLong ? MakeFit(item.label) : item.label;
                if (c.label) c.label.text = text;

                if (c.icon) { c.icon.sprite = item.icon; c.icon.enabled = (item.icon != null); }

                c.button.onClick.RemoveAllListeners();
                if (item.onClick != null) c.button.onClick.AddListener(() => item.onClick.Invoke());
            }

            for (; gridIdx < _grid.Count; gridIdx++) _grid[gridIdx].go.SetActive(false);

            UpdatePager(_currentPage, pages);
        }

        private void ApplyPagerMode(int current, int total)
        {
            if (!pagerText) return;

            if (pagerStackVertical)
            {
                // Use explicit newline characters so we don't create multi-line literals in code.
                pagerText.text = current.ToString() + "\n" + pagerDivider + "\n" + total.ToString();
                pagerText.alignment = TextAlignmentOptions.Center;
                if (pagerLabelLE != null)
                {
                    pagerLabelLE.minWidth = 40f;
                    pagerLabelLE.preferredWidth = 40f;
                    pagerLabelLE.minHeight = Mathf.Max(pagerButtonSize.y, 60f);
                    pagerLabelLE.preferredHeight = Mathf.Max(pagerButtonSize.y, 60f);
                }
            }
            else
            {
                pagerText.text = current.ToString() + pagerSlash + total.ToString();
                pagerText.alignment = TextAlignmentOptions.Center;
                if (pagerLabelLE != null)
                {
                    pagerLabelLE.minWidth = 120f;
                    pagerLabelLE.preferredWidth = 120f;
                    pagerLabelLE.minHeight = pagerButtonSize.y;
                    pagerLabelLE.preferredHeight = pagerButtonSize.y;
                }
            }
        }
    }
}
