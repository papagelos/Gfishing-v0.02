using UnityEngine;
using UnityEngine.InputSystem;
using GalacticFishing.UI;

public class MenuRouter : MonoBehaviour
{
    [Header("Inventory Window")]
    [SerializeField] private InventoryWindowController inventoryWindow;

    [Header("Inventory Views (inside Inventory-background)")]
    [Tooltip("The root that shows the normal 13x6 inventory view.")]
    [SerializeField] private GameObject contentFrame;

    [Tooltip("The root that shows the 2x4 card/upgrade view (CardviewRoot).")]
    [SerializeField] private GameObject cardviewRoot;

    [Header("Other UI Roots (optional)")]
    [SerializeField] private GameObject panelHub;     // Panel_Hub
    [SerializeField] private GameObject museumPanel;  // MuseumPanel (if used)

    // internal state
    private bool inventoryOpen;          // is the inventory window currently open?
    private bool inventoryOpenedFromHub; // did we open it from Panel_Hub?
    // true while Museum + 2x4 card view are open together
    private bool museumInventoryOpen = false;

    // Tracks which high-level screen is currently open.
    private enum MenuScreen
    {
        Gameplay,
        InventoryGrid,
        UpgradeCards,
        Museum,
        Hub
    }

    [SerializeField]
    private MenuScreen currentScreen = MenuScreen.Gameplay;

    private void Awake()
    {
        // We start with everything closed, world running.
        inventoryOpen        = false;
        inventoryOpenedFromHub = false;

        if (cardviewRoot != null)  cardviewRoot.SetActive(false);
        // contentFrame you probably want disabled at startup too – do that in the scene if needed.
    }

    private void Update()
    {
        var kb = Keyboard.current;
        if (kb == null)
            return;

        if (kb[Key.Escape].wasPressedThisFrame)
        {
            HandleEscape();
        }
    }

    // --------------------------------------------------------------------
    // PUBLIC API – call these from buttons / quickbar
    // --------------------------------------------------------------------

    /// <summary>Open inventory while you are inside the Hub (Panel_Hub).</summary>
    public void OpenInventoryFromHub()
    {
        inventoryOpenedFromHub = true;
        OpenInventoryGrid();
    }

    /// <summary>Open inventory directly from the world (Quickbar, future hotkey, etc).</summary>
    public void OpenInventoryFromWorld()
    {
        inventoryOpenedFromHub = false;
        OpenInventoryGrid();
    }

    public void OpenInventoryGrid()
    {
        Debug.Log("[MenuRouter] OpenInventoryGrid()");

        if (panelHub != null)
            panelHub.SetActive(false);

        if (museumPanel != null)
            museumPanel.SetActive(false);

        if (inventoryWindow != null)
            inventoryWindow.Show();

        if (contentFrame != null)
            contentFrame.SetActive(true);

        if (cardviewRoot != null)
            cardviewRoot.SetActive(false);

        inventoryOpen = true;
        museumInventoryOpen = false;
        currentScreen = MenuScreen.InventoryGrid;
    }

    /// <summary>Open the upgrade cards screen.</summary>
    public void OpenUpgradeCards()
    {
        Debug.Log("[MenuRouter] OpenUpgradeCards()");

        if (panelHub != null)
            panelHub.SetActive(false);

        if (museumPanel != null)
            museumPanel.SetActive(false);

        if (inventoryWindow != null)
            inventoryWindow.Show();

        if (contentFrame != null)
            contentFrame.SetActive(false);

        if (cardviewRoot != null)
            cardviewRoot.SetActive(true);

        inventoryOpen = true;
        museumInventoryOpen = false;
        currentScreen = MenuScreen.UpgradeCards;
    }

    public void OpenMuseumSell()
    {
        // We are entering the Museum Sell view:
        // - Hide the hub
        // - Show museum backdrop
        // - Open the inventory window, but with 2x4 cards instead of the 13x6 grid
        museumInventoryOpen = true;

        if (panelHub != null)
            panelHub.SetActive(false);

        if (museumPanel != null)
            museumPanel.SetActive(true);

        if (inventoryWindow != null)
            inventoryWindow.Show();

        if (contentFrame != null)
            contentFrame.SetActive(false);

        if (cardviewRoot != null)
            cardviewRoot.SetActive(true);

        inventoryOpen = true;
        currentScreen = MenuScreen.Museum;
    }

    private void HandleEscape()
    {
        switch (currentScreen)
        {
            case MenuScreen.InventoryGrid:
            case MenuScreen.UpgradeCards:
            case MenuScreen.Museum:
            case MenuScreen.Hub:
                CloseAllAndReturnToGameplay();
                break;

            case MenuScreen.Gameplay:
            default:
                break;
        }
    }

    private void CloseAllAndReturnToGameplay()
    {
        Debug.Log("[MenuRouter] CloseAllAndReturnToGameplay()");

        if (inventoryWindow != null)
            inventoryWindow.Hide();

        if (contentFrame != null)
            contentFrame.SetActive(false);

        if (cardviewRoot != null)
            cardviewRoot.SetActive(false);

        if (panelHub != null)
            panelHub.SetActive(false);

        if (museumPanel != null)
            museumPanel.SetActive(false);

        inventoryOpen = false;
        inventoryOpenedFromHub = false;
        museumInventoryOpen = false;
        currentScreen = MenuScreen.Gameplay;

        // Make sure the world is actually running again.
        ResetGameplayState();
    }

    /// <summary>
    /// Ensure the world is un-paused and gameplay block flag is cleared.
    /// Call this whenever we fully return to gameplay (no menus open).
    /// </summary>
    private void ResetGameplayState()
    {
        if (Time.timeScale != 1f)
            Time.timeScale = 1f;

        // Clear any global gameplay-block flag set by UIBlocksGameplay.
        UIBlocksGameplay.GameplayBlocked = false;
    }

    /// <summary>One-step back navigation, driven by Escape.</summary>
    public void Back()
    {
        if (museumInventoryOpen)
        {
            // Leaving the Museum Sell view: close cards, close museum, return to hub
            museumInventoryOpen = false;

            if (inventoryWindow != null)
                inventoryWindow.Hide();

            if (cardviewRoot != null)
                cardviewRoot.SetActive(false);

            if (museumPanel != null)
                museumPanel.SetActive(false);

            if (panelHub != null)
                panelHub.SetActive(true);

            currentScreen = MenuScreen.Hub;
            return;
        }

        // 1) If inventory is open, that is always top of the stack.
        if (inventoryOpen)
        {
            CloseInventory();

            if (inventoryOpenedFromHub && panelHub != null)
            {
                // We came from Hub -> Inventory, so go back to Hub.
                panelHub.SetActive(true);
                currentScreen = MenuScreen.Hub;
            }
            else
            {
                // We came directly from gameplay.
                currentScreen = MenuScreen.Gameplay;
                ResetGameplayState();
            }

            return;
        }

        // 2) No inventory – next priority: close Museum if it is open.
        if (museumPanel != null && museumPanel.activeSelf)
        {
            museumPanel.SetActive(false);
            currentScreen = MenuScreen.Gameplay;
            ResetGameplayState();
            return;
        }

        // 3) Finally, if Hub is open, close it to go back to world.
        if (panelHub != null && panelHub.activeSelf)
        {
            panelHub.SetActive(false);
            currentScreen = MenuScreen.Gameplay;
            ResetGameplayState();
            return;
        }

        // 4) Nothing to close -> already in world.
    }

    // --------------------------------------------------------------------
    // INTERNAL HELPERS
    // --------------------------------------------------------------------

    private void CloseInventory()
    {
        if (inventoryWindow != null)
            inventoryWindow.Hide();

        inventoryOpen = false;

        // Hide both views – the next screen we go to will decide what to show.
        if (contentFrame != null)
            contentFrame.SetActive(false);

        if (cardviewRoot != null)
            cardviewRoot.SetActive(false);

        // If we did NOT come from Hub, then closing inventory means go back to world UI.
        if (!inventoryOpenedFromHub && panelHub != null)
        {
            // We *don't* reopen the hub in this case – we came from the world.
            // World just continues running; Hub stays as it was (usually disabled).
        }
    }
}
