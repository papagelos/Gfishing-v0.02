using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using System.Linq;
using System;                 // <-- for Action
using GalacticFishing;        // <-- for Fish

public enum Rarity { Common, Uncommon, Rare, Epic, Legendary, Mythic }

[System.Serializable]
public class ItemData
{
    // NEW: identity info so a slot can open the right records page
    public int RegistryId = -1;     // index in FishRegistry (or -1 for non-fish items later)
    public Fish FishDef;            // optional reference to the Fish ScriptableObject

    public Sprite Icon;
    public int Count = 0;
    public Rarity Rarity = Rarity.Common;
    public bool Disabled = false;
    [TextArea] public string Tooltip; // pretty name
}

public class InventorySlot : MonoBehaviour,
    IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
{
    [Header("Wiring")]
    [SerializeField] private Image icon;
    [SerializeField] private TMP_Text countLabel;

    [Header("Optional Visuals")]
    [SerializeField] private CanvasGroup canvasGroup;   // for dimming/disable
    [SerializeField] private Image hoverGlow;           // optional
    [SerializeField] private Image pressedMask;         // optional
    [Header("Legacy/Compat (optional)")]
    [SerializeField] private Image frame;               // optional (for older utilities)
    [SerializeField] private Image disabledMask;        // optional (for older utilities)
    [SerializeField] private Image countBadge;          // optional badge under the count label
    [Header("Visuals")]
    [SerializeField] private Sprite zeroCountSprite;    // fallback sprite when empty

    [Header("Rarity (Optional ring swap)")]
    [SerializeField] private Image rarityRing;
    [SerializeField] private Sprite common, uncommon, rare, epic, legendary, mythic;

    [Header("Formatting")]
    [SerializeField] private bool useCompactNumbers = true;

    ItemData bound;
    public int CurrentCount => bound != null ? bound.Count : 0;

    // >>> NEW: expose the bound data for the grid <<<
    public ItemData Data => bound;

    // NEW: grid listens to this to open the Records page
    public Action<InventorySlot> Clicked;

    void Awake()
    {
        if (!icon) icon = GetComponentsInChildren<Image>(true).FirstOrDefault(i => i.name.ToLower().Contains("icon"));
        if (icon) { icon.preserveAspect = true; icon.raycastTarget = true; } // <-- make slot raycastable

        if (!countLabel) countLabel = GetComponentsInChildren<TMP_Text>(true).FirstOrDefault(t => t.name.ToLower().Contains("count"));
        if (countLabel) { countLabel.enabled = true; countLabel.gameObject.SetActive(true); countLabel.raycastTarget = false; }

        if (countBadge)
        {
            countBadge.raycastTarget = false;
            countBadge.enabled = true;
            if (countBadge.gameObject) countBadge.gameObject.SetActive(false);
        }

        if (hoverGlow)   hoverGlow.raycastTarget   = false;
        if (pressedMask) pressedMask.raycastTarget = false;
        if (disabledMask)disabledMask.raycastTarget= false;
        if (rarityRing)  rarityRing.raycastTarget  = false;
    }

    public InventorySlot Bind(ItemData data)
    {
        bound = data;

        if (icon)
        {
            if (data.Count <= 0)
            {
                icon.enabled = zeroCountSprite != null;
                icon.sprite = zeroCountSprite;
            }
            else
            {
                icon.enabled = data.Icon != null;
                if (data.Icon != null) icon.sprite = data.Icon;
            }
        }

        if (countLabel)
        {
            bool has = data.Count > 0;
            countLabel.text = has ? (useCompactNumbers ? Compact(data.Count) : Mathf.Max(0, data.Count).ToString()) : string.Empty;

            if (countBadge)
            {
                if (countBadge.gameObject) countBadge.gameObject.SetActive(has);
                countBadge.enabled = has;
            }
        }

        if (rarityRing)
        {
            rarityRing.enabled = true;
            rarityRing.sprite = data.Rarity switch
            {
                Rarity.Uncommon  => uncommon,
                Rarity.Rare      => rare,
                Rarity.Epic      => epic,
                Rarity.Legendary => legendary,
                Rarity.Mythic    => mythic,
                _                => common,
            };
        }

        if (hoverGlow)   hoverGlow.enabled   = false;
        if (pressedMask) pressedMask.enabled = false;
        if (disabledMask)disabledMask.enabled= false;
        ApplyDisabled(data.Disabled);
        return this;
    }

    public void SetIcon(Sprite sprite)
    {
        if (!icon) return;
        icon.enabled = sprite != null;
        icon.sprite = sprite;
    }

    static string Compact(int value)
    {
        if (value >= 1_000_000_000) return (value / 1_000_000_000f).ToString("0.#") + "b";
        if (value >= 1_000_000)     return (value / 1_000_000f).ToString("0.#") + "m";
        if (value >= 1_000)         return (value / 1_000f).ToString("0.#") + "k";
        return Mathf.Max(0, value).ToString();
    }

    void ApplyDisabled(bool disabled)
    {
        if (canvasGroup)
        {
            canvasGroup.alpha = disabled ? 0.33f : 1f;
            canvasGroup.interactable = !disabled;
            canvasGroup.blocksRaycasts = !disabled;
        }
        else
        {
            if (icon) icon.color = disabled ? new Color(1,1,1,0.33f) : Color.white;
            if (countLabel) countLabel.alpha = disabled ? 0.5f : 1f;
        }
        if (disabledMask) disabledMask.enabled = disabled;
    }

    // ----- Pointer events: UI has priority over world -----
    public void OnPointerEnter(PointerEventData _)
    {
        if (!IsDisabled() && hoverGlow) hoverGlow.enabled = true;

        if (bound != null && bound.Count > 0 && bound.Icon != null)
            InventoryHoverName.ShowUI(bound.Tooltip);
        else
            InventoryHoverName.ShowUI(""); // clears to default
    }

    public void OnPointerExit (PointerEventData _)
    {
        if (hoverGlow) hoverGlow.enabled = false;
        InventoryHoverName.ClearUI();
    }

    public void OnPointerDown (PointerEventData _){ if (!IsDisabled() && pressedMask) pressedMask.enabled = true; }

    public void OnPointerUp   (PointerEventData _)
    {
        if (pressedMask) pressedMask.enabled = false;

        // click-to-open (only if this slot actually represents at least one owned item)
        if (!IsDisabled() && bound != null && bound.Count > 0)
        {
            Clicked?.Invoke(this);
        }
    }

    bool IsDisabled() => bound != null && bound.Disabled;

    // Legacy accessors so older tools compile without changes.
    public Image Frame         => frame;
    public Image IconImage     => icon;
    public Image RarityRingImg => rarityRing;
    public Image PressedMaskImg=> pressedMask;
    public Image DisabledMask  => disabledMask;
    public TMP_Text CountText  => countLabel;
}
